const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const androidMain = path.join(root, 'android', 'app', 'src', 'main');
const resDir = path.join(androidMain, 'res');
const assetsDir = path.join(root, 'android-assets');

if (!fs.existsSync(androidMain)) {
  console.error('Folder android/ belum ditemukan. Jalankan "npx cap add android" terlebih dahulu.');
  process.exit(1);
}

// 1. Update MainActivity.java (Back button navigasi WebView + double-tap exit + WebView settings)
const mainActivityPath = path.join(
  androidMain,
  'java',
  'id',
  'biz',
  'freshlaundry',
  'app',
  'MainActivity.java'
);

const mainActivityJava = `package id.biz.freshlaundry.app;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private long lastBackPressedTime = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                WebView webView = getBridge() != null ? getBridge().getWebView() : null;
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                    return;
                }

                long now = System.currentTimeMillis();
                if (now - lastBackPressedTime < 2000) {
                    finish();
                } else {
                    lastBackPressedTime = now;
                    Toast.makeText(
                        MainActivity.this,
                        "Tekan kembali sekali lagi untuk keluar",
                        Toast.LENGTH_SHORT
                    ).show();
                }
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        if (getBridge() != null && getBridge().getWebView() != null) {
            WebView webView = getBridge().getWebView();
            WebSettings settings = webView.getSettings();
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setSupportZoom(false);
            settings.setBuiltInZoomControls(false);
            settings.setDisplayZoomControls(false);
            webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        }
    }
}
`;
fs.mkdirSync(path.dirname(mainActivityPath), { recursive: true });
fs.writeFileSync(mainActivityPath, mainActivityJava, 'utf8');
console.log('[OK] MainActivity.java diperbarui.');

// 2. Patch AndroidManifest.xml (Izin jaringan, lokasi untuk peta antar-jemput, dan queries WhatsApp)
const manifestPath = path.join(androidMain, 'AndroidManifest.xml');
let manifest = fs.readFileSync(manifestPath, 'utf8');

const permissions = [
  'android.permission.INTERNET',
  'android.permission.ACCESS_NETWORK_STATE',
  'android.permission.ACCESS_COARSE_LOCATION',
  'android.permission.ACCESS_FINE_LOCATION',
];

for (const perm of permissions) {
  if (!manifest.includes(perm)) {
    manifest = manifest.replace(
      '</manifest>',
      `    <uses-permission android:name="${perm}" />
</manifest>`
    );
  }
}

if (!manifest.includes('<queries>')) {
  const queriesBlock = `    <queries>
        <package android:name="com.whatsapp" />
        <package android:name="com.whatsapp.w4b" />
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="https" />
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="whatsapp" />
        </intent>
    </queries>
</manifest>`;
  manifest = manifest.replace('</manifest>', queriesBlock);
}

fs.writeFileSync(manifestPath, manifest, 'utf8');
console.log('[OK] AndroidManifest.xml diperbarui.');

// 3. Patch colors & launcher background (warna Butik Aqua #111e58)
const valuesDir = path.join(resDir, 'values');
fs.mkdirSync(valuesDir, { recursive: true });

const bgXmlPath = path.join(valuesDir, 'ic_launcher_background.xml');
fs.writeFileSync(
  bgXmlPath,
  `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#111E58</color>
</resources>
`,
  'utf8'
);

const colorsXmlPath = path.join(valuesDir, 'colors.xml');
fs.writeFileSync(
  colorsXmlPath,
  `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="colorPrimary">#1646AC</color>
    <color name="colorPrimaryDark">#111E58</color>
    <color name="colorAccent">#30DBD5</color>
</resources>
`,
  'utf8'
);
console.log('[OK] Warna tema Android (colors.xml & ic_launcher_background.xml) diperbarui.');

// 4. Copy Freshy Laundry App Icons
const mipmaps = ['mipmap-mdpi', 'mipmap-hdpi', 'mipmap-xhdpi', 'mipmap-xxhdpi', 'mipmap-xxxhdpi'];
for (const mip of mipmaps) {
  const srcFolder = path.join(assetsDir, mip);
  const dstFolder = path.join(resDir, mip);
  if (fs.existsSync(srcFolder)) {
    fs.mkdirSync(dstFolder, { recursive: true });
    for (const file of fs.readdirSync(srcFolder)) {
      fs.copyFileSync(path.join(srcFolder, file), path.join(dstFolder, file));
    }
  }
}
console.log('[OK] Ikon aplikasi Freshy Laundry diterapkan.');

// 5. Replace Splash Screen PNGs across drawable folders
const portSplash = path.join(assetsDir, 'splash', 'splash-port.png');
const landSplash = path.join(assetsDir, 'splash', 'splash-land.png');

if (fs.existsSync(portSplash) && fs.existsSync(landSplash)) {
  for (const entry of fs.readdirSync(resDir)) {
    if (entry.startsWith('drawable')) {
      const targetSplash = path.join(resDir, entry, 'splash.png');
      if (fs.existsSync(targetSplash)) {
        const src = entry.includes('-land-') ? landSplash : portSplash;
        fs.copyFileSync(src, targetSplash);
      }
    }
  }
  const defaultSplash = path.join(resDir, 'drawable', 'splash.png');
  fs.mkdirSync(path.dirname(defaultSplash), { recursive: true });
  fs.copyFileSync(portSplash, defaultSplash);
  console.log('[OK] Splash Screen Freshy Laundry diterapkan.');
}
