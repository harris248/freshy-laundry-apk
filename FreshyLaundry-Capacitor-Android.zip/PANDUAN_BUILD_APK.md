# Freshy Laundry — Aplikasi Android (Capacitor)

Project ini membungkus website live **https://freshlaundry.biz.id/** menjadi aplikasi Android (`.apk`) menggunakan **Capacitor 6** dengan:
- Tampilan, fitur pelanggan, kasir/admin, checkout, QRIS, live chat, dan database **100% sama & real-time** dengan website `https://freshlaundry.biz.id/`.
- Ikon aplikasi & Splash Screen bertema **Butik Aqua Freshy Laundry**.
- Tombol **Back** Android berfungsi kembali ke halaman sebelumnya (dan tekan 2x untuk keluar di halaman utama).
- Tombol **WhatsApp Admin / Pelanggan** otomatis membuka aplikasi WhatsApp di HP.
- Halaman **Offline** khusus jika koneksi internet HP terputus.

---

## Cara 1: Auto-Build APK Gratis lewat GitHub (Tanpa Android Studio)

1. Ekstrak file ZIP ini di komputer/HP.
2. Buat repository baru di [GitHub](https://github.com/new) (boleh **Public** atau **Private**), misalnya beri nama `freshy-laundry-apk`.
3. Upload semua isi folder project ini ke repository tersebut:
   - **Disarankan pakai Git (CMD / Terminal)** supaya folder tersembunyi `.github` pasti ikut ter-upload:
     ```bash
     git init
     git add .
     git commit -m "Initial Freshy Laundry Capacitor APK"
     git branch -M main
     git remote add origin https://github.com/USERNAME_KAMU/freshy-laundry-apk.git
     git push -u origin main
     ```
   - **Jika upload lewat browser GitHub**: pastikan file `.github/workflows/build-apk.yml` ikut masuk. Jika belum terlihat di repo, klik **Add file → Create new file**, ketik nama file `.github/workflows/build-apk.yml`, lalu salin isi file tersebut dari folder hasil ekstrak.
4. Buka tab **Actions** di repository GitHub kamu.
5. Tunggu workflow **Build Freshy Laundry APK** selesai (± 3–5 menit hingga centang hijau).
   *(Kamu juga bisa jalankan manual kapan saja lewat tombol **Run workflow**).*
6. Klik workflow yang sudah hijau → gulir ke bagian **Artifacts** → klik **FreshyLaundry-Android-APK** untuk mengunduh ZIP berisi `FreshyLaundry-Android.apk`.
7. Kirim `FreshyLaundry-Android.apk` ke HP Android dan install! (Aktifkan *Install dari sumber tidak dikenal / Unknown sources* jika diminta).

---

## Cara 2: Build Lokal di Laptop (Android Studio / Terminal)

Pastikan sudah terinstall **Node.js 20+**, **Java 17**, dan **Android Studio / Android SDK**:

```bash
npm install
npm run android:init
cd android
./gradlew assembleDebug
```

File APK hasil build ada di:
`android/app/build/outputs/apk/debug/app-debug.apk`

Atau jalankan `npm run android:open` untuk membuka project langsung di Android Studio lalu pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
